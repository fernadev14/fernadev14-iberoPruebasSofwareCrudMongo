package com.ibero.crudmongo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudmongoApplicationTests {

	@Test
	void contextLoads() {
	}

}
