package com.ibero.crudmongo.service;

import com.ibero.crudmongo.model.Persona;
import java.util.List;
import java.util.Optional;


public interface PersonaService {
    
    List<Persona> getAllPersonas();
    Optional<Persona> getPersonaById(Long id);
    Persona savePersona(Persona persona);
    
    void deletePersonaById(Long id);
    
    
    
    
}
