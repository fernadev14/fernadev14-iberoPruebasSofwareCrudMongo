package com.ibero.crudmongo.model.api;

import com.ibero.crudmongo.model.Persona;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface PersonaRepository extends MongoRepository<Persona, Long>{
    
    
    
}
